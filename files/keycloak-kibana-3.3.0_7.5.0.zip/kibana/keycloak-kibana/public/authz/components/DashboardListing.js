/*
 * The dashboard listening component enriched with dashboard ownership feature.
 * Original source: https://github.com/elastic/kibana/blob/7.2/src/legacy/core_plugins/kibana/public/dashboard/listing/dashboard_listing.js
 */
/* eslint-disable import/no-unresolved */

import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { injectI18n, FormattedMessage } from '@kbn/i18n/react';
import { i18n } from '@kbn/i18n';

import {
  EuiLink,
  EuiButton,
  EuiEmptyPrompt,
} from '@elastic/eui';

// import { TableListView } from './../../table_list_view';
import { TableListView } from './TableListView';

export const EMPTY_FILTER = '';

// saved object client does not support sorting by title because title is only mapped as analyzed
// the legacy implementation got around this by pulling `listingLimit` items and doing client side sorting
// and not supporting server-side paging.
// This component does not try to tackle these problems (yet) and is just feature matching the legacy component
// TODO support server side sorting/paging once title and description are sortable on the server.
class DashboardListingUi extends React.Component {

  constructor(props) {
    super(props);
  }

  render() {
    return (
      <TableListView
        createItem={this.props.hideWriteControls ? null : this.props.createItem}
        findItems={this.props.findItems}
        deleteItems={this.props.hideWriteControls ? null : this.props.deleteItems}
        editItem={this.props.hideWriteControls ? null : this.props.editItem}
        tableColumns={this.getTableColumns()}
        listingLimit={this.props.listingLimit}
        initialFilter={this.props.initialFilter}
        noItemsFragment={this.getNoItemsMessage()}
        entityName={
          i18n.translate('kbn.dashboard.listing.table.entityName', {
            defaultMessage: 'dashboard'
          })
        }
        entityNamePlural={
          i18n.translate('kbn.dashboard.listing.table.entityNamePlural', {
            defaultMessage: 'dashboards'
          })
        }
        tableListTitle={
          i18n.translate('kbn.dashboard.listing.dashboardsTitle', {
            defaultMessage: 'Dashboards'
          })
        }
        ownership={this.props.ownership}
      />
    );
  }

  getNoItemsMessage() {
    if (this.props.hideWriteControls) {
      return (
        <div>
          <EuiEmptyPrompt
            iconType="visualizeApp"
            title={
              <h2>
                <FormattedMessage
                  id="kbn.dashboard.listing.noItemsMessage"
                  defaultMessage="Looks like you don't have any dashboards."
                />
              </h2>
            }
          />
        </div>
      );
    }

    return (
      <div>
        <EuiEmptyPrompt
          iconType="dashboardApp"
          title={
            <h2>
              <FormattedMessage
                id="kbn.dashboard.listing.createNewDashboard.title"
                defaultMessage="Create your first dashboard"
              />
            </h2>
          }
          body={
            <Fragment>
              <p>
                <FormattedMessage
                  id="kbn.dashboard.listing.createNewDashboard.combineDataViewFromKibanaAppDescription"
                  defaultMessage="You can combine data views from any Kibana app into one dashboard and see everything in one place."
                />
              </p>
              <p>
                <FormattedMessage
                  id="kbn.dashboard.listing.createNewDashboard.newToKibanaDescription"
                  defaultMessage="New to Kibana? {sampleDataInstallLink} to take a test drive."
                  values={{
                    sampleDataInstallLink: (
                      <EuiLink href="#/home/tutorial_directory/sampleData">
                        <FormattedMessage
                          id="kbn.dashboard.listing.createNewDashboard.sampleDataInstallLinkText"
                          defaultMessage="Install some sample data"
                        />
                      </EuiLink>
                    ),
                  }}
                />
              </p>
            </Fragment>
          }
          actions={
            <EuiButton
              onClick={this.props.createItem}
              fill
              iconType="plusInCircle"
              data-test-subj="createDashboardPromptButton"
            >
              <FormattedMessage
                id="kbn.dashboard.listing.createNewDashboard.createButtonLabel"
                defaultMessage="Create new dashboard"
              />
            </EuiButton>
          }
        />
      </div>
    );

  }

  getTableColumns() {
    const tableColumns = [
      {
        field: 'title',
        name: i18n.translate('kbn.dashboard.listing.table.titleColumnName', {
          defaultMessage: 'Title'
        }),
        sortable: true,
        render: (field, record) => (
          <EuiLink
            href={this.props.getViewUrl(record)}
            data-test-subj={`dashboardListingTitleLink-${record.title.split(' ').join('-')}`}
          >
            {field}
          </EuiLink>
        )
      },
      {
        field: 'description',
        name: i18n.translate('kbn.dashboard.listing.table.descriptionColumnName', {
          defaultMessage: 'Description'
        }),
        dataType: 'string',
        sortable: true,
      }
    ];
    return tableColumns;
  }
}

DashboardListingUi.propTypes = {
  createItem: PropTypes.func.isRequired,
  findItems: PropTypes.func.isRequired,
  deleteItems: PropTypes.func.isRequired,
  editItem: PropTypes.func.isRequired,
  getViewUrl: PropTypes.func.isRequired,
  listingLimit: PropTypes.number.isRequired,
  hideWriteControls: PropTypes.bool.isRequired,
  initialFilter: PropTypes.string,

  /* ADDED */
  ownership: PropTypes.object
};

DashboardListingUi.defaultProps = {
  initialFilter: EMPTY_FILTER,
};

export const DashboardListing = injectI18n(DashboardListingUi);
